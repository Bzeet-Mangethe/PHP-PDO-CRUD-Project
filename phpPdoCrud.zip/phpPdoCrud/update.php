<?php
    
include 'connect.php';
$id=$_GET['updateid'];
$sql="select * from `interns` where id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);

$name=$row['firstname'];
$surname=$row['lastname'];

if(isset($_POST['submit'])){

    $name=$_POST['name'];
    $surname=$_POST['surname'];

    $sql="update `interns` set id=$id,firstname= '$name',lastname='$surname' where id=$id";

    $result=mysqli_query($con,$sql);
    if($result)
    {
       //echo " updated successfully";
       header('location:display.php');
    }
    else{
        die(mysqli_error($con));
    }
}


?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

    <title>PHP PDO CRUD!</title>
  </head>
  <body>
    <div class ="container my-5">
    <form method="post">

  <div class="form-group">
    <label > First Name</label>
    <input type="text" class="form-control"
    placeholder=" Enter First name" name ="name" autocomplete="off" value=<?php echo $name;?>>
  </div>

  <div class="form-group">
    <label > Last Name</label>
    <input type="text" class="form-control"
    placeholder=" Enter Last name" name ="surname" autocomplete="off" value=<?php echo $surname;?>>
  </div>

<button type ="submit" class="btn btn-primary" name="submit">Update</button>
</form> 
    </div>

   
</body>
</html>
<?php
    
include 'connect.php';
if(isset($_POST['submit'])){

    $name=$_POST['name'];
    $surname=$_POST['surname'];

    $sql="insert into `interns` (firstname,lastname)
    values(' $name','$surname')";

    $result=mysqli_query($con,$sql);
    if($result)
    {
       // echo " data inserted successfully";
       header('location:display.php');
    }
    else{
        die(mysqli_error($con));
    }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

    <title>PHP PDO CRUD!</title>
  </head>
  <body>
    <div class ="container my-5">
    <form method="post">

  <div class="form-group">
    <label > First Name</label>
    <input type="text" class="form-control"
    placeholder=" Enter First name" name ="name" autocomplete="off">
  </div>

  <div class="form-group">
    <label > Last Name</label>
    <input type="text" class="form-control"
    placeholder=" Enter Last name" name ="surname" autocomplete="off">
  </div>

<button type ="submit" class="btn btn-primary" name="submit">Submit</button>
</form> 
    </div>

   
</body>
</html>
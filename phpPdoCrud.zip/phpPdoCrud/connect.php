<?php
    
    $con=new mysqli('localhost','root','','interndb');

    if(!$con)
    {
        die(mysqli_error($con));

    }
   
?>